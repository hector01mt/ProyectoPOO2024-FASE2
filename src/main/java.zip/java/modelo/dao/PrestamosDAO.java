/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Conexion;
import modelo.Prestamos;

/**
 *
 * @author Hector Marquez
 */
public class PrestamosDAO {
    
     // Crear un nuevo préstamo
    public boolean insertarPrestamo(Prestamos prestamo) {
        String sql = "INSERT INTO prestamos (id_usuario, id_item, fecha_prestamo, fecha_devolucion, devuelto, mora) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, prestamo.getIdUsuario());
            stmt.setInt(2, prestamo.getIdItem());
            stmt.setDate(3, new java.sql.Date(prestamo.getFechaPrestamo().getTime()));
            stmt.setDate(4, new java.sql.Date(prestamo.getFechaDevolucion().getTime()));
            stmt.setBoolean(5, prestamo.isDevuelto());
            stmt.setDouble(6, prestamo.getMora());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Actualizar estado del préstamo (devolución)
    public boolean marcarDevuelto(int idPrestamo, double mora) {
        String sql = "UPDATE prestamos SET devuelto = ?, mora = ? WHERE id_prestamo = ?";
        try (Connection conn = Conexion.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(1, true);
            stmt.setDouble(2, mora);
            stmt.setInt(3, idPrestamo);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Listar préstamos por usuario
    public List<Prestamos> listarPrestamosPorUsuario(int idUsuario) {
        List<Prestamos> prestamos = new ArrayList<>();
        String sql = "SELECT * FROM prestamos WHERE id_usuario = ?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Prestamos prestamo = mapResultSetToPrestamo(rs);
                    prestamos.add(prestamo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prestamos;
    }
    
    public List<Prestamos> listarPendientes() {
        List<Prestamos> prestamos = new ArrayList<>();
        String sql = "SELECT * FROM prestamos WHERE devuelto = false";
        try (Connection conn = Conexion.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                prestamos.add(mapResultSetToPrestamo(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prestamos;
    }

    // Mapear ResultSet a un objeto Prestamo
    private Prestamos mapResultSetToPrestamo(ResultSet rs) throws SQLException {
        return new Prestamos(
                rs.getInt("id_prestamo"),
                rs.getInt("id_usuario"),
                rs.getInt("id_item"),
                rs.getDate("fecha_prestamo"),
                rs.getDate("fecha_devolucion"),
                rs.getBoolean("devuelto"),
                rs.getDouble("mora")
        );
    }
    
}
