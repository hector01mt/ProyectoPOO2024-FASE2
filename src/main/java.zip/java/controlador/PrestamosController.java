/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.List;
import modelo.Prestamos;
import modelo.dao.PrestamosDAO;

/**
 *
 * @author Hector Marquez
 */
public class PrestamosController {
    
    private final PrestamosDAO prestamoDAO;

    public PrestamosController() {
        this.prestamoDAO = new PrestamosDAO();
    }

    public boolean registrarPrestamo(Prestamos prestamo) {
        return prestamoDAO.insertarPrestamo(prestamo);
    }

//    public boolean devolverPrestamo(int idPrestamo) {
//        return prestamoDAO.marcarDevuelto(idPrestamo);
//    }

    public List<Prestamos> listarPrestamosPorUsuario(int idUsuario) {
        return prestamoDAO.listarPrestamosPorUsuario(idUsuario);
    }
    
    public boolean marcarDevuelto(int idPrestamo, double mora) {
    return prestamoDAO.marcarDevuelto(idPrestamo, mora);
    }
    
    public List<Prestamos> listarPendientes() {
    return prestamoDAO.listarPendientes();
}
    
}
